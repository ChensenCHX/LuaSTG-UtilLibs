# LuaSTG UI库部分重置

由于原UI.lua的实现过于难以描述,不由得让人有一种改一改的冲动  
实用库,使用时直接用该目录内文件替换原THlib\UI\ 下的同名文件以及launcher.lua和THlib.lua  
  
UI方案表的写法详见CHXuiLib.lua最后的注释段,或参考CHXuiConfig.lua中提供的原UI的写法实现  

本库尚未完全完成  
  
data重置计划0.5/+∞  
